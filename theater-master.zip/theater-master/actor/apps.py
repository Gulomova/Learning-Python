from django.apps import AppConfig


class ActorConfig(AppConfig):
    name = 'actor'
