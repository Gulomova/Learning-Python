from django.apps import AppConfig


class MdtConfig(AppConfig):
    name = 'mdt'
