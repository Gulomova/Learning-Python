﻿export class News {
  pk: string;
  title: string;
  date_time: string;
  description: string;
  phone: string;
}
