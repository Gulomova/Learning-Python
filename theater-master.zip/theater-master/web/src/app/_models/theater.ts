﻿export class Theater {
  pk: string;
  name: string;
  short_name: string;
  description: string;
  author_description: string;
  photo_1: string;
  photo_2: string;
  photo_3: string;
  photo_4: string;
  photo_5: string;
  photo_6: string;
  photo_7: string;
  photo_8: string;
  phones: string[];
  email: string;
  address: string;
  address_name: string;
  ticket_window: string;
  facebook_link: string;
  vk_link: string;
  instagram_link: string;
}
