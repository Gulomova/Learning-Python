﻿export class Actor {
  pk: string;
  first_name: string;
  last_name: string;
  position: string;
  photo_v: string;
  photo_h: string;
}
