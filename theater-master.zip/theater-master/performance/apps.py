from django.apps import AppConfig


class PerformanceConfig(AppConfig):
    name = 'performance'
